# Foto Live Module (LSPosed)

1. Abrí la carpeta en Android Studio y compilá (Build > Build APK).
2. Instalá el APK en el Samsung con root + LSPosed.
3. En LSPosed: activá el módulo y marcá solo "Cámara" (com.sec.android.app.camera).
4. Forzá cierre de la cámara y abrila de nuevo.
5. Mirá los logs en LSPosed (Registros) o `adb logcat | grep FotoLive`:
   ahí vas a ver los nombres reales de los flags de cámara.
   Agregá los de foto en movimiento a `forceTrueKeys` en MainHook.kt.
6. Si la cámara sigue sin mostrar la opción, probá cambiar `fakeModel` por otro modelo.
