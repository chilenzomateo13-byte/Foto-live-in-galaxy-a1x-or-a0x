package com.fotolive.module

import android.os.Build
import de.robv.android.xposed.IXposedHookLoadPackage
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedBridge
import de.robv.android.xposed.XposedHelpers
import de.robv.android.xposed.callbacks.XC_LoadPackage

class MainHook : IXposedHookLoadPackage {

    // Modelo que va a "fingir" la cámara. Cambialo por uno que SÍ tenga foto en movimiento.
    private val fakeModel = "SM-A556B"      // Galaxy A55
    private val fakeDevice = "a55x"
    private val fakeName = "a55xnaxx"

    // Palabras clave de flags que se fuerzan a true. Ajustalas con lo que veas en logcat.
    private val forceTrueKeys = listOf("MOTION_PHOTO", "MOTIONPHOTO", "LIVE_PHOTO", "SHOT_AND_MORE")

    override fun handleLoadPackage(lpparam: XC_LoadPackage.LoadPackageParam) {
        if (lpparam.packageName != "com.sec.android.app.camera") return
        log("Cargado en la cámara de Samsung")

        // 1) Cambiar la identidad del dispositivo solo dentro del proceso de la cámara
        try {
            XposedHelpers.setStaticObjectField(Build::class.java, "MODEL", fakeModel)
            XposedHelpers.setStaticObjectField(Build::class.java, "DEVICE", fakeDevice)
            XposedHelpers.setStaticObjectField(Build::class.java, "PRODUCT", fakeName)
        } catch (t: Throwable) {
            log("Error cambiando Build: $t")
        }

        // 2) Forzar flags de features (SemFloatingFeature)
        try {
            val cls = XposedHelpers.findClass(
                "com.samsung.android.feature.SemFloatingFeature", lpparam.classLoader
            )
            val hook = object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    val key = param.args.getOrNull(0) as? String ?: return
                    if (key.contains("CAMERA", true)) log("Feature consultado: $key -> ${param.result}")
                    if (forceTrueKeys.any { key.contains(it, true) }) {
                        param.result = true
                        log("FORZADO true: $key")
                    }
                }
            }
            XposedBridge.hookAllMethods(cls, "getBoolean", hook)
        } catch (t: Throwable) {
            log("No se pudo hookear SemFloatingFeature: $t")
        }
    }

    private fun log(msg: String) = XposedBridge.log("[FotoLive] $msg")
}
